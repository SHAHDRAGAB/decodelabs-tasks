from django.urls import path

from ecommerce.shipping.views.create_shipment_view import (
    CreateShipmentView
)

from ecommerce.shipping.views.track_shipment_view import (
    TrackShipmentView
)

urlpatterns = [

    path(
        "create/<str:order_id>/",
        CreateShipmentView.as_view()
    ),

    path(
        "track/<str:tracking_number>/",
        TrackShipmentView.as_view()
    ),
]