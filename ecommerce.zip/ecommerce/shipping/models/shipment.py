from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField
)

from datetime import datetime

from ecommerce.orders.models.order import (
    Order
)


class Shipment(Document):

    order = ReferenceField(
        Order,
        required=True
    )

    tracking_number = StringField()

    carrier = StringField()

    status = StringField(
        choices=[
            "processing",
            "packed",
            "shipped",
            "in_transit",
            "delivered"
        ],
        default="processing"
    )

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "shipments"
    }