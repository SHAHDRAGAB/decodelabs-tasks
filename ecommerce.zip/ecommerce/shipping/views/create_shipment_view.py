import uuid

from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from rest_framework.permissions import (
    IsAdminUser
)

from ecommerce.orders.models.order import (
    Order
)

from ecommerce.shipping.models.shipment import (
    Shipment
)



class CreateShipmentView(APIView):

    permission_classes = [
        IsAdminUser
    ]
    

    def post(self, request, order_id):

        order = Order.objects(
            id=order_id
        ).first()
        

        if not order:

            return Response({
                "error":
                "Order not found"
            })

        shipment = Shipment(

            order=order,

            tracking_number=
            str(uuid.uuid4())[:10],

            carrier=request.data.get(
                "carrier"
            )
        )

        shipment.save()

        order.status = "shipped"
        order.save()

        return Response({

            "message":
            "Shipment created",

            "tracking_number":
            shipment.tracking_number
        })