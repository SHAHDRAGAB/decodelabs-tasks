from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from ecommerce.shipping.models.shipment import (
    Shipment
)


class TrackShipmentView(APIView):

    def get(self, request, tracking_number):

        shipment = Shipment.objects(
            tracking_number=
            tracking_number
        ).first()

        if not shipment:

            return Response({
                "error":
                "Shipment not found"
            })

        return Response({

            "tracking_number":
            shipment.tracking_number,

            "status":
            shipment.status,

            "carrier":
            shipment.carrier
        })