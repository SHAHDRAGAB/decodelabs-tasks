from django.urls import path

from ecommerce.categories.views.create_category_view import (
    CreateCategoryView
)

urlpatterns = [

    path("create/",CreateCategoryView.as_view(),name="create-category"),
]