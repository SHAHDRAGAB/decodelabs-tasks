from rest_framework import serializers
from ecommerce.categories.models.category import (Category)


class CategorySerializer(
    serializers.Serializer
):

    id = serializers.CharField(
        read_only=True
    )

    name = serializers.CharField()

    slug = serializers.CharField()

    description = serializers.CharField()

    created_at = serializers.DateTimeField(
        read_only=True
    )

    def create(self, validated_data):

        category = Category(
            **validated_data
        )

        category.save()

        return category