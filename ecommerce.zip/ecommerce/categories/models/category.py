from mongoengine import (
    Document,
    StringField,
    DateTimeField
)

from datetime import datetime


class Category(Document):

    name = StringField(required=True,unique=True)

    slug = StringField(required=True,unique=True)

    description = StringField()

    created_at = DateTimeField(default=datetime.utcnow)

    meta = {
        "collection": "categories"
    }

    def str(self):
        return self.name