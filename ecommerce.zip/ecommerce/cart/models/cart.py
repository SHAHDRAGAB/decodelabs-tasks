from mongoengine import (
    Document,
    ReferenceField,
    IntField,
    DateTimeField
)

from datetime import datetime

from accounts.models.user import User

from ecommerce.products.models.product import Product


class Cart(Document):

    user = ReferenceField(
        User,
        required=True
    )

    product = ReferenceField(
        Product,
        required=True
    )

    quantity = IntField(
        default=1
    )

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "cart"
    }