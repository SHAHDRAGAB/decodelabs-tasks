from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from ecommerce.cart.models.cart import Cart
from ecommerce.products.models.product import Product


class AddToCartView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self, request):

        user = request.user

        product_id = request.data.get("product_id")
        quantity = int(request.data.get("quantity", 1))

        product = Product.objects(id=product_id).first()

        if not product:
            return Response({"error": "Product not found"})

        if product.stock < quantity:
            return Response({"error": "Not enough stock"})

        cart_item = Cart.objects(
            user=user,
            product=product
        ).first()

        if cart_item:

            cart_item.quantity += quantity
            cart_item.save()

        else:

            Cart(
                user=user,
                product=product,
                quantity=quantity
            ).save()

        return Response({
            "message": "Added to cart successfully"
        })