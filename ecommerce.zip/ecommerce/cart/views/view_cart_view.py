from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from ecommerce.cart.models.cart import Cart


class ViewCartView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):

        user = request.user

        cart_items = Cart.objects(user=user)

        data = []
        total = 0

        for item in cart_items:

            product = item.product

            item_total = product.price * item.quantity
            total += item_total

            data.append({
                "product_id": str(product.id),
                "title": product.title,
                "price": product.price,
                "quantity": item.quantity,
                "item_total": item_total
            })

        return Response({
            "items": data,
            "total_price": total
        })