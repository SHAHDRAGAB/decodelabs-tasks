from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from ecommerce.cart.models.cart import Cart


class UpdateCartView(APIView):

    permission_classes = [IsAuthenticated]

    def patch(self, request):

        user = request.user

        product_id = request.data.get("product_id")
        quantity = int(request.data.get("quantity"))

        cart_item = Cart.objects(
            user=user,
            product=product_id
        ).first()

        if not cart_item:
            return Response({"error": "Item not found"})

        if quantity <= 0:
            cart_item.delete()
        else:
            cart_item.quantity = quantity
            cart_item.save()

        return Response({"message": "Cart updated"})