from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from ecommerce.cart.models.cart import Cart


class RemoveFromCartView(APIView):

    permission_classes = [IsAuthenticated]

    def delete(self, request):

        user = request.user

        product_id = request.data.get("product_id")

        cart_item = Cart.objects(
            user=user,
            product=product_id
        ).first()

        if cart_item:
            cart_item.delete()

        return Response({
            "message": "Item removed"
        })