from django.urls import path

from ecommerce.cart.views.add_to_cart_view import AddToCartView
from ecommerce.cart.views.view_cart_view import ViewCartView
from ecommerce.cart.views.update_cart_view import UpdateCartView
from ecommerce.cart.views.remove_from_cart_view import RemoveFromCartView

urlpatterns = [
    path("add/", AddToCartView.as_view()),
    path("", ViewCartView.as_view()),
    path("update/", UpdateCartView.as_view()),
    path("remove/", RemoveFromCartView.as_view()),
]