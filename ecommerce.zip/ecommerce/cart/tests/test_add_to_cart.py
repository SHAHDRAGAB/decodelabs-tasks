from rest_framework.test import (
    APITestCase
)


class AddToCartTest(
    APITestCase
):

    def test_add_to_cart(self):

        response = self.client.post(

            "/api/cart/add/",

            {

                "product_id":
                "PRODUCT_ID",

                "quantity":
                2
            }
        )

        self.assertEqual(
            response.status_code,
            200
        )