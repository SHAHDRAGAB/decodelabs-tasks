from rest_framework import serializers

from ecommerce.products.models.product import (
    Product
)

from ecommerce.categories.models.category import (
    Category
)


class ProductSerializer(
    serializers.Serializer
):

    id = serializers.CharField(
        read_only=True
    )

    title = serializers.CharField()

    slug = serializers.CharField()

    description = serializers.CharField()

    category_id = serializers.CharField(write_only=True)

    brand = serializers.CharField()

    price = serializers.FloatField()

    stock = serializers.IntegerField()

    hearing_level = serializers.CharField()

    battery_type = serializers.CharField()

    bluetooth_support = serializers.BooleanField()

    rechargeable = serializers.BooleanField()

    noise_cancellation = serializers.BooleanField()

    ear_side = serializers.CharField()

    images = serializers.ListField()

    is_active = serializers.BooleanField(
        read_only=True
    )

    created_at = serializers.DateTimeField(
        read_only=True
    )

    def create(self, validated_data):

        category_id = validated_data.pop(
            "category_id"
        )

        category = Category.objects(
            id=category_id
        ).first()

        if not category:
            raise serializers.ValidationError(
                "Invalid category"
            )

        product = Product(
            category=category,
            **validated_data
        )

        product.save()

        return product