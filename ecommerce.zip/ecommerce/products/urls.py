from django.urls import path

from ecommerce.products.views.create_product_view import (
    CreateProductView
)

from ecommerce.products.views.list_products_view import (
    ListProductsView
)

from ecommerce.products.views.product_details_view import (
    ProductDetailsView
)

from ecommerce.products.views.search_products_view import (
    SearchProductsView
)

urlpatterns = [

    path(
        "create/",
        CreateProductView.as_view(),
        name="create-product"
    ),

    path(
        "",
        ListProductsView.as_view(),
        name="list-products"
    ),

    path(
        "<str:slug>/",
        ProductDetailsView.as_view(),
        name="product-details"
    ),

    path(
        "search/",
        SearchProductsView.as_view(),
        name="search-products"
    ),
]