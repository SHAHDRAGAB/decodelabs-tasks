from rest_framework.views import APIView
from rest_framework.response import Response
from ecommerce.products.models.product import Product


class ListProductsView(APIView):

    def get(self, request):

        try:
            page = int(request.GET.get("page", 1))
            limit = int(request.GET.get("limit", 10))
        except ValueError:
            return Response(
                {"error": "page and limit must be integers"},
                status=400
            )

        page = max(page, 1)
        limit = max(limit, 1)

        start = (page - 1) * limit
        end = start + limit

        queryset = Product.objects(is_active=True).order_by("-created_at")

        total = queryset.count()

        products = queryset[start:end]

        data = []

        for product in products:
            data.append({
                "id": str(product.id),
                "title": product.title,
                "slug": product.slug,
                "price": product.price,
                "brand": product.brand,
                "stock": product.stock,
                "hearing_level": product.hearing_level,
                "bluetooth_support": product.bluetooth_support,
                "image": product.images[0] if product.images else None
            })

        return Response({
            "page": page,
            "limit": limit,
            "total": total,
            "results": data
        })