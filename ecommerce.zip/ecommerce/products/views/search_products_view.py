from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from ecommerce.products.models.product import (
    Product
)


class SearchProductsView(APIView):

    def get(self, request):

        query = request.GET.get(
            "query"
        )

        category = request.GET.get(
            "category"
        )

        brand = request.GET.get(
            "brand"
        )

        products = Product.objects(
            is_active=True
        )

        if query:

            products = products.filter(
                title__icontains=query
            )

        if category:

            products = products.filter(
                category=category
            )

        if brand:

            products = products.filter(
                brand__icontains=brand
            )

        data = []

        for product in products:

            data.append({

                "id": str(product.id),

                "title": product.title,

                "price": product.price,

                "brand": product.brand,

                "image":
                product.images[0]
                if product.images else None
            })

        return Response(data)