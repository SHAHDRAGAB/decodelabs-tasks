from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from rest_framework import status

from ecommerce.products.models.product import (
    Product
)


class ProductDetailsView(APIView):

    def get(self, request, slug):

        product = Product.objects(
            slug=slug,
            is_active=True
        ).first()

        if not product:

            return Response(
                {
                    "error": "Product not found"
                },
                status=status.HTTP_404_NOT_FOUND
            )

        data = {

            "id": str(product.id),

            "title": product.title,

            "slug": product.slug,

            "description":
            product.description,

            "category":
            product.category.name
            if product.category else None,

            "brand": product.brand,

            "price": product.price,

            "stock": product.stock,

            "hearing_level":
            product.hearing_level,

            "battery_type":
            product.battery_type,

            "bluetooth_support":
            product.bluetooth_support,

            "rechargeable":
            product.rechargeable,

            "noise_cancellation":
            product.noise_cancellation,

            "ear_side":
            product.ear_side,

            "images":
            product.images
        }

        return Response(data)