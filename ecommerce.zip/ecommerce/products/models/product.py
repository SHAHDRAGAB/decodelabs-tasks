from mongoengine import (
    Document,
    StringField,
    FloatField,
    IntField,
    BooleanField,
    ReferenceField,
    ListField,
    DateTimeField
)

from datetime import datetime

from ecommerce.categories.models.category import (
    Category
)


class Product(Document):

    title = StringField(required=True)

    slug = StringField(required=True, unique=True)

    description = StringField()

    category = ReferenceField(Category)

    brand = StringField()

    price = FloatField(
        required=True
    )

    stock = IntField(
        default=0
    )

    hearing_level = StringField()

    battery_type = StringField()

    bluetooth_support = BooleanField(
        default=False
    )

    rechargeable = BooleanField(
        default=False
    )

    noise_cancellation = BooleanField(
        default=False
    )

    ear_side = StringField(
        choices=[
            "left",
            "right",
            "both"
        ]
    )

    images = ListField(
        StringField()
    )

    is_active = BooleanField(
        default=True
    )

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "products"
    }

    def str(self):

        return self.title