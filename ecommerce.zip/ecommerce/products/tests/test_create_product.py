from rest_framework.test import (
    APITestCase
)

from accounts.models import User


class CreateProductTest(
    APITestCase
):

    def setUp(self):

        self.user = User(
            email="admin@test.com",
            role="admin"
        )

        self.user.set_password(
            "123456"
        )

        self.user.save()

    def test_create_product(self):

        response = self.client.post(

            "/api/products/create/",

            {

                "title":
                "Test Product",

                "slug":
                "test-product",

                "price":
                100
            },

            HTTP_AUTHORIZATION=
            "Bearer TOKEN"
        )

        self.assertEqual(
            response.status_code,
            201
        )