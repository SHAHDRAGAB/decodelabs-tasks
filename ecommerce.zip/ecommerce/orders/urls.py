from django.urls import path

from ecommerce.orders.views.checkout_view import (
    CheckoutView
)

from ecommerce.orders.views.order_history_view import (
    OrderHistoryView
)

from ecommerce.orders.views.order_details_view import (
    OrderDetailsView
)

urlpatterns = [

    path(
        "checkout/",
        CheckoutView.as_view()
    ),

    path(
        "",
        OrderHistoryView.as_view()
    ),

    path(
        "<str:order_id>/",
        OrderDetailsView.as_view()
    ),
]