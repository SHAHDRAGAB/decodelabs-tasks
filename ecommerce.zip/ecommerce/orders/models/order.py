from mongoengine import (
    Document,
    ReferenceField,
    FloatField,
    StringField,
    DateTimeField
)

from datetime import datetime

from accounts.models.user import User


class Order(Document):

    user = ReferenceField(
        User,
        required=True
    )

    total_price = FloatField(
        default=0
    )

    status = StringField(
        choices=[
            "pending",
            "paid",
            "processing",
            "shipped",
            "delivered",
            "cancelled"
        ],
        default="pending"
    )

    shipping_address = StringField()

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "orders"
    }