from mongoengine import (
    Document,
    ReferenceField,
    IntField,
    FloatField
)

from ecommerce.orders.models.order import (
    Order
)

from ecommerce.products.models.product import (
    Product
)


class OrderItem(Document):

    order = ReferenceField(
        Order,
        required=True
    )

    product = ReferenceField(
        Product,
        required=True
    )

    quantity = IntField(
        default=1
    )

    price = FloatField()

    meta = {
        "collection": "order_items"
    }