from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from rest_framework.permissions import (
    IsAuthenticated
)

from ecommerce.orders.models.order import (
    Order
)


class OrderHistoryView(APIView):

    permission_classes = [
        IsAuthenticated
    ]

    def get(self, request):

        user = request.user

        orders = Order.objects(
            user=user
        )

        data = []

        for order in orders:

            data.append({

                "id": str(order.id),

                "total_price":
                order.total_price,

                "status":
                order.status,

                "shipping_address":
                order.shipping_address,

                "created_at":
                order.created_at
            })

        return Response(data)