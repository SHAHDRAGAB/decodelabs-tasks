from rest_framework.views import APIView

from rest_framework.response import Response

from rest_framework.permissions import IsAuthenticated

from rest_framework import status

from ecommerce.cart.models.cart import Cart

from ecommerce.orders.models.order import Order
from ecommerce.orders.models.order_item import OrderItem

from notifications.services.email_service import (
    EmailService
)
from notifications.tasks.send_email_task import (
    send_email_task
)



class CheckoutView(APIView):

    permission_classes = [
        IsAuthenticated
    ]

    def post(self, request):

        user = request.user

        shipping_address = request.data.get(
            "shipping_address"
        )

        cart_items = Cart.objects(
            user=user
        )

        if not cart_items:

            return Response(
                {
                    "error": "Cart is empty"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        total_price = 0

        for item in cart_items:

            product = item.product

            if product.stock < item.quantity:

                return Response(
                    {
                        "error":
                        f"{product.title} out of stock"
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            total_price += (
                product.price * item.quantity
            )

        order = Order(
            user=user,
            total_price=total_price,
            shipping_address=shipping_address
        )

        order.save()

        for item in cart_items:

            product = item.product

            OrderItem(
                order=order,
                product=product,
                quantity=item.quantity,
                price=product.price
            ).save()

            product.stock -= item.quantity
            product.save()

            item.delete()

        # Send Email
        send_email_task.delay(

    "Order Created",

    f"Your order {order.id} was created.",

    user.email
)

        return Response({

            "message":
            "Order created successfully",

            "order_id":
            str(order.id),

            "total_price":
            total_price

        })