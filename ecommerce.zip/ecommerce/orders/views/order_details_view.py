from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from rest_framework.permissions import (
    IsAuthenticated
)

from rest_framework import status

from ecommerce.orders.models.order import Order
from ecommerce.orders.models.order_item import OrderItem


class OrderDetailsView(APIView):

    permission_classes = [
        IsAuthenticated
    ]

    def get(self, request, order_id):

        order = Order.objects(
            id=order_id,
            user=request.user
        ).first()

        if not order:

            return Response(
                {
                    "error":
                    "Order not found"
                },
                status=status.HTTP_404_NOT_FOUND
            )

        items = OrderItem.objects(
            order=order
        )

        order_items = []

        for item in items:

            order_items.append({

                "product":
                item.product.title,

                "quantity":
                item.quantity,

                "price":
                item.price
            })

        return Response({

            "id":
            str(order.id),

            "status":
            order.status,

            "total_price":
            order.total_price,

            "items":
            order_items
        })