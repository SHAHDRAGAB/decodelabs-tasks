import stripe

from django.conf import settings

from django.http import HttpResponse

from ecommerce.orders.models.order import (
    Order
)

stripe.api_key = (
    settings.STRIPE_SECRET_KEY
)


class StripeWebhookView:

    def post(self, request):

        payload = request.body

        sig_header = request.META.get(
            "HTTP_STRIPE_SIGNATURE"
        )

        endpoint_secret = "YOUR_WEBHOOK_SECRET"

        try:

            event = stripe.Webhook.construct_event(
                payload,
                sig_header,
                endpoint_secret
            )

        except Exception:

            return HttpResponse(status=400)

        if event["type"] == \
            "checkout.session.completed":

            session = event["data"]["object"]

            order_id = session[
                "metadata"
            ]["order_id"]

            order = Order.objects(
                id=order_id
            ).first()

            if order:

                order.status = "paid"
                order.save()

        return HttpResponse(status=200)