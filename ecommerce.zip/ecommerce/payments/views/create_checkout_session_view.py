import stripe

from django.conf import settings

from rest_framework.views import APIView

from rest_framework.response import Response

from rest_framework.permissions import IsAuthenticated

from ecommerce.orders.models.order import Order

stripe.api_key = settings.STRIPE_SECRET_KEY


class CreateCheckoutSessionView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self, request, order_id):

        order = Order.objects(
            id=order_id,
            user=request.user
        ).first()

        if not order:

            return Response({
                "error": "Order not found"
            }, status=404)

        session = stripe.checkout.Session.create(

            payment_method_types=[
                "card"
            ],

            line_items=[{

                "price_data": {

                    "currency": "usd",

                    "product_data": {

                        "name":
                        f"Order {order.id}"
                    },

                    "unit_amount":
                    int(order.total_price * 100)
                },

                "quantity": 1

            }],

            mode="payment",

            success_url=
            "http://127.0.0.1:8000/payment-success/",

            cancel_url=
            "http://127.0.0.1:8000/payment-cancel/",

            metadata={
                "order_id": str(order.id)
            }
        )

        return Response({
            "checkout_url": session.url
        })