from django.urls import path

from ecommerce.payments.views.create_checkout_session_view import (
    CreateCheckoutSessionView
)

urlpatterns = [

    path(
        "checkout/<str:order_id>/",
        CreateCheckoutSessionView.as_view()
    ),
]