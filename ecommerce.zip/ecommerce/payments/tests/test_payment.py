from rest_framework.test import (
    APITestCase
)


class PaymentTest(APITestCase):

    def test_create_checkout(self):

        response = self.client.post(
            "/api/payments/checkout/1/"
        )

        self.assertEqual(
            response.status_code,
            200
        )