from mongoengine import (
    Document,
    ReferenceField,
    IntField,
    DateTimeField
)

from datetime import datetime

from ecommerce.products.models import (
    Product
)


class Inventory(Document):

    product = ReferenceField(
        Product,
        required=True,
        unique=True
    )

    quantity = IntField(
        default=0
    )

    reserved_quantity = IntField(
        default=0
    )

    low_stock_threshold = IntField(
        default=5
    )

    updated_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "inventory"
    }