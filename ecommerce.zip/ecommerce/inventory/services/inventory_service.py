from ecommerce.inventory.models import (
    Inventory
)


class InventoryService:

    @staticmethod
    def reduce_stock(product, quantity):

        inventory = Inventory.objects(
            product=product
        ).first()

        if not inventory:
            return False

        if inventory.quantity < quantity:
            return False

        inventory.quantity -= quantity
        inventory.save()

        return True

    @staticmethod
    def is_low_stock(product):

        inventory = Inventory.objects(
            product=product
        ).first()

        if not inventory:
            return False

        return (
            inventory.quantity <=
            inventory.low_stock_threshold
        )