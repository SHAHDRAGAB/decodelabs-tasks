from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from rest_framework.permissions import (
    IsAdminUser
)

from ecommerce.inventory.models import (
    Inventory
)


class LowStockProductsView(APIView):

    permission_classes = [
        IsAdminUser
    ]

    def get(self, request):

        inventory_items = Inventory.objects()

        data = []

        for item in inventory_items:

            if (
                item.quantity <=
                item.low_stock_threshold
            ):

                data.append({

                    "product":
                    item.product.title,

                    "quantity":
                    item.quantity
                })

        return Response(data) 