from accounts.models.user import User
from accounts.models.role import Role


def run_seeds():

    if not Role.objects(name="admin").first():
        Role(name="admin").save()

    admin_role = Role.objects(name="admin").first()

    # 👇 مهم جدًا: check قبل إنشاء user
    if not User.objects(email="admin@test.com").first():

        admin = User(
            full_name="Admin",
            email="admin@test.com",
            role=admin_role,
            is_active=True
        )

        admin.set_password("123456")
        admin.save()

    print("Seeds executed safely ")