from django.urls import path
from .views.register_view import RegisterView 
from.views.ResendOTPView import ResendOTPView
from .views.login_view import LoginView
from accounts.views.me_view import MeView
from accounts.views.refresh_view import RefreshTokenView
from accounts.views.logout_view import LogoutView
from accounts.views.dashboard_view import AdminDashboard
from accounts.views.login_history_view import LoginHistoryView
from accounts.views.verify_email_otp_view import VerifyEmailOTPView
from accounts.views.forgot_password_view import ForgotPasswordView
from accounts.views.reset_password_view import ResetPasswordView
from accounts.views.verify_otp_view import VerifyOTPView
from accounts.views.enable_mfa_view import EnableMFAView
from accounts.views.google_login_view import GoogleLoginView
from accounts.views.session_view import SessionsView
from accounts.views.logout_session_view import LogoutSessionView
from accounts.views.create_organization_view import CreateOrganizationView


urlpatterns = [
    # 1 work
    path("Register/",RegisterView.as_view(),name="register"),
    # 2 
    path("Resend-otp/",ResendOTPView.as_view(),name="resend-otp"), 
    # 3 Login
    path("Login/",LoginView.as_view(),name="login"),
    # 4
    path("Me/",MeView.as_view(),name="me"),
    # 5
    path("Refresh/",RefreshTokenView.as_view(),name="refresh"),
    # 6
    path("Logout/", LogoutView.as_view(),name="logout"),
    # 7
    path("Dashboard/", AdminDashboard.as_view(),name="dashboard"),
    # 8
    path("Login-history/", LoginHistoryView.as_view(),name="login-history"),
    # 9 work
    path("Verify-email/",VerifyEmailOTPView.as_view(),name="verify-email"),
    # 10
    path("Forgot-password/",ForgotPasswordView.as_view(),name="forgot-password"),
    # 11
    path("Reset-password/<str:token>/",ResetPasswordView.as_view(),name="reset-password"),
    # 12 WORK
    path("Verify-otp/",VerifyOTPView.as_view(),name="verify-otp"),
    # 13
    path("Enable-mfa/",EnableMFAView.as_view(),name="enable-mfa"),
    # 14
    path("Google-login/",GoogleLoginView.as_view(),name="google-login"),
    # 15
    path("Sessions/",SessionsView.as_view(),name="sessions"),
    # 16
    path("Sessions/Logout/<str:session_id>/",LogoutSessionView.as_view(),name="logout-session"),
    # 17
    path("Organizations/Create/",CreateOrganizationView.as_view(),name="create-organization"),
    # 18
]
