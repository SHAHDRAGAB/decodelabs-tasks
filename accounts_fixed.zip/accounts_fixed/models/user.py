from mongoengine import Document
from mongoengine.fields import (
    IntField,
    StringField,
    EmailField,
    BooleanField,
    DateTimeField,
    ReferenceField
)

from django.contrib.auth.hashers import (
    make_password,
    check_password
)

from datetime import datetime

from accounts.models.role import Role
from accounts.models.organization import Organization


class User(Document):

    FREE = "free"
    PLUS = "plus"
    ULTRA = "ultra"

    PLAN_CHOICES = [
        (FREE, "Free"),
        (PLUS, "Plus"),
        (ULTRA, "Ultra")
    ]

    role = ReferenceField(Role)

    full_name = StringField(
        required=False,
        default="User"
    )

    # username = StringField()

    email = EmailField(
        required=True,
        unique=True
    )

    password = StringField(
        required=True
    )
    
    phone_number=StringField()
    address=StringField()

    point_balance = IntField()

    daily_transaction_count = IntField()

    subscribation_plan_id = StringField(
        choices=PLAN_CHOICES,
        default=FREE
    )

    mfa_enabled = BooleanField(
        default=False
    )

    organization = ReferenceField(
        Organization
    )

    is_verified = BooleanField(
        default=False
    )

    is_active = BooleanField(
        default=True
    )
    
    is_staff = BooleanField(default=False)

    is_superuser = BooleanField(default=False)
    
    def save(self, *args, **kwargs):

        if self.role:

            role_name = self.role.name.lower()

            
            self.is_staff = (
            role_name == "admin"
            )

            self.is_superuser = (
            role_name == "admin"
             )
        return super().save(*args,**kwargs)

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "users"
    }

    

    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    def set_password(
        self,
        raw_password
    ):

        self.password = make_password(
            raw_password
        )

        return self

    def check_password(
        self,
        raw_password
    ):

        return check_password(
            raw_password,
            self.password
        )