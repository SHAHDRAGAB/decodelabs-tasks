from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField
)
from datetime import timedelta , datetime

from datetime import datetime, timedelta

from accounts.models.user import User


class EmailOTP(Document):

    user = ReferenceField(
        User,
        required=True
    )

    otp_code = StringField(
        required=True
    )

    expires_at = DateTimeField( 
        required=True , 
    )

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection":
        "email_otps"
    }

    @property
    def is_expired(self):

        return datetime.utcnow() > self.expires_at