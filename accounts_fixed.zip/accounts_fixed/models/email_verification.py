from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField,
    BooleanField
)

from datetime import datetime

from accounts.models.user import User


class EmailVerificationToken(Document):

    user = ReferenceField(User)

    token = StringField(required=True)

    is_used = BooleanField(default=False)

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "email_verification_tokens"
    }