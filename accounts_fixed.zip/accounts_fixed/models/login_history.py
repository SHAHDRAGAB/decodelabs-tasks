from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField
)

from datetime import datetime

from accounts.models.user import User


class LoginHistory(Document):

    user = ReferenceField(User)

    ip_address = StringField()

    user_agent = StringField()

    login_time = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "login_history"
    }