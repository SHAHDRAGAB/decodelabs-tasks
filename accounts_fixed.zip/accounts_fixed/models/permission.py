from mongoengine import Document
from mongoengine.fields import (StringField)

class Permission(Document):

    name = StringField(
        required=True,
        unique=True
    )

    description = StringField()


    meta = {
        "collection":"permissions"
    }