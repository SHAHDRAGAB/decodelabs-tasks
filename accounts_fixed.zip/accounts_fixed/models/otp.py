from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField,
    BooleanField
)

from datetime import datetime,timedelta

from accounts.models.user import User


class OTP(Document):

    user = ReferenceField(User)
    
    is_used = BooleanField(default=False)
    expires_at = DateTimeField(
        default=lambda: datetime.utcnow() + timedelta(minutes=5)
    )

    code = StringField(required=True)

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "otp_codes"
    }
    
    
    @property
    def is_expired(self):
        return datetime.utcnow() > self.expires_at