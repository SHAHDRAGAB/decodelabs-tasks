from mongoengine import Document
from mongoengine.fields import StringField,DateTimeField
from datetime import datetime

class BlackListedToken(Document) :
    token=StringField(required=True,unique=True)
    created_at=DateTimeField(default=datetime.utcnow)
    meta={
        "collection":"blacklisted_tokens"
    }