from mongoengine import (
    Document,
    ReferenceField,
    StringField,
    DateTimeField,
    BooleanField
)

from datetime import datetime

from accounts.models.user import User


class Session(Document):

    user = ReferenceField(User)

    refresh_token = StringField()

    ip_address = StringField()

    user_agent = StringField()

    is_active = BooleanField(default=True)

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "sessions"
    }