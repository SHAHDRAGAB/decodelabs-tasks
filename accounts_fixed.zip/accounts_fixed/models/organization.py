from mongoengine import (
    Document,
    StringField,
    DateTimeField
)

from datetime import datetime


class Organization(Document):

    name = StringField(
        required=True,
        unique=True
    )

    slug = StringField(
        required=True,
        unique=True
    )

    created_at = DateTimeField(
        default=datetime.utcnow
    )

    meta = {
        "collection": "organizations"
    }

    def str(self):
        return self.name