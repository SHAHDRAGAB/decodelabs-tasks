from mongoengine import Document
from mongoengine.fields import ReferenceField,ListField,StringField
from accounts.models.permission import Permission
from accounts.models.organization import Organization
class Role(Document):

    name = StringField(
        required=True,
        unique=True
    )


    permissions = ListField(
        ReferenceField(Permission)
    )


    meta = {
        "collection":"roles"
    }