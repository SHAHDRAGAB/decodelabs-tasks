from rest_framework import serializers
from accounts.models.user import User
from accounts.models.role import Role
from accounts.services.otp_service import create_email_otp
from accounts.services.email_service import send_verification_email


class RegisterSerializers(serializers.Serializer):

    full_name = serializers.CharField()
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)
    phone_number = serializers.CharField()
    address = serializers.CharField()

    role = serializers.CharField(required=False)

    subscribation_plan_id = serializers.ChoiceField(
        choices=User.PLAN_CHOICES,
        default=User.FREE
    )

    def validate_email(self, value):

        if User.objects(email=value).first():
            raise serializers.ValidationError("Email already exists")

        return value

    def create(self, validated_data):

        password = validated_data.pop("password")
        role_name = validated_data.pop("role", None)

        role = None

        if role_name:
            role = Role.objects(name=role_name.lower()).first()

            if not role:
                raise serializers.ValidationError("Invalid role")

        user = User(
            role=role,
            full_name=validated_data.get("full_name"),
            email=validated_data.get("email"),
            phone_number=validated_data.get("phone_number"),
            address=validated_data.get("address"),
            subscribation_plan_id=validated_data.get("subscribation_plan_id", User.FREE),
        )

        user.set_password(password)
        user.save()

        otp = create_email_otp(user)
        send_verification_email(user, otp)

        return user