from rest_framework import serializers
from accounts.models.user import User

class LoginSerializers(serializers.Serializer):
    email=serializers.EmailField()
    password=serializers.CharField()
    
    def validate(self , data):
        user=User.objects(email=data['email']).first()
        if not user :
            raise serializers.ValidationError("Invalid Credentials")
        if not user.check_password(data['password']):
            raise serializers.ValidationError("Invalid Credentials")
        data['user']=user
        return data
        
