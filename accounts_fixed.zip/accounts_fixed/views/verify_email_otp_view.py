from rest_framework.views import APIView

from rest_framework.response import (
    Response
)

from accounts.models.user import User

from accounts.models.email_otp import (
    EmailOTP
)


class VerifyEmailOTPView(APIView):

    def post(self, request):

        email = request.data.get("email", "").strip().lower()

        otp = request.data.get(
            "otp"
        )

        user = User.objects(
            email=email
        ).first()

        if not user:

            return Response({

                "message":
                "User not found","status":"404_NOT_FOUND"
            })

        otp_record = EmailOTP.objects(

            user=user,

            otp_code=otp

        ).first()

        if not otp_record:

            return Response({

                "message":
                "Invalid OTP","status":"400_BAD_REQUEST"
            })

        if otp_record.is_expired:

            return Response({

                "message":
                "OTP expired","status":"400_BAD_REQUEST"
            })

        user.is_verified = True

        user.save()

        otp_record.delete()

        return Response({

            "message":
            "Email verified successfully","status":"200_OK"
        })