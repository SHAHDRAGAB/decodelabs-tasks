from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from accounts.models.user import User
from accounts.services.jwt_services import (decode_token,generate_access_token,is_blacklisted)
class RefreshTokenView(APIView):
    def post(self,request):
        refresh_token=request.data.get("refresh")
        if not refresh_token:
            return Response(
                {
                    "message":"Refresh Token Required","status":"400_BAD_REQUEST"
                },status=status.HTTP_400_BAD_REQUEST
            )
            
        try:
            if is_blacklisted(refresh_token):
                return Response ({"message":"Token Blacklisted","status":"401_UNAUTHORIZED"},status=status.HTTP_401_UNAUTHORIZED)
            
            payload=decode_token(refresh_token)
            if payload['type']!="refresh":
                return Response({"message":"Invalid Token Type","status":"401_UNAUTHORIZED"},status=status.HTTP_401_UNAUTHORIZED)
            user=User.objects(id=payload["user_id"]).first()
            if not user:
                return Response({"message":"User Not Found","status":"404_NOT_FOUND"},status=status.HTTP_404_NOT_FOUND)
            access_token=generate_access_token(user)
            return Response({"access":access_token},status=status.HTTP_200_OK)
        except Exception:
            return Response({"message":"Invalid or Expired token","status":"401_UNAUTHORIZED"},status=status.HTTP_401_UNAUTHORIZED)