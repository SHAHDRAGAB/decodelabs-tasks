from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from accounts.models.user import User
from accounts.models.session import Session

from accounts.services.google_service import verify_google_token
from accounts.services.jwt_services import (
    generate_access_token,
    generate_refresh_token
)


class GoogleLoginView(APIView):

    permission_classes = []  # مهم: مفتوح لأي مستخدم

    def post(self, request):

        token = request.data.get("token")

        if not token:
            return Response(
                {"message": "Token required","status":"400_BAD_REQUEST"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 🔐 Verify Google Token safely
        user_info = verify_google_token(token)

        if not user_info:
            return Response(
                {"message": "Invalid Google token","status":"HTTP_401_UNAUTHORIZED"},
                status=status.HTTP_401_UNAUTHORIZED
            )

        email = user_info.get("email")
        name = user_info.get("name")

        if not email:
            return Response(
                {"message": "Google account has no email","status":"400_BAD_REQUEST"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 👤 Get or Create User
        user = User.objects(email=email).first()

        if not user:
            user = User(
                email=email,
                username=email.split("@")[0],
                is_verified=True
            )
            user.save()

        # 🚫 Optional: check if user is active
        if hasattr(user, "is_active") and not user.is_active:
            return Response(
                {"error": "Account disabled"},
                status=status.HTTP_403_FORBIDDEN
            )

        # 🔑 Generate tokens
        access_token = generate_access_token(user)
        refresh_token = generate_refresh_token(user)

        # 📌 Create session (important for tracking devices)
        Session(
            user=user,
            refresh_token=refresh_token,
            ip_address=request.META.get("REMOTE_ADDR"),
            user_agent=request.META.get("HTTP_USER_AGENT"),
            is_active=True
        ).save()

        return Response(
            {
                "access": access_token,
                "refresh": refresh_token,
                "user": {
                    "email": user.email,
                    "username": user.username
                }
            },
            status=status.HTTP_200_OK
        )