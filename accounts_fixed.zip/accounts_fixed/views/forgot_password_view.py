from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from drf_yasg.utils import swagger_auto_schema

from accounts.models.user import User
from accounts.models.password_reset import PasswordResetToken

from accounts.serializers.forget_password_serializer import ForgotPasswordSerializer
from accounts.utils.token_generator import (
    generate_verification_token
)
from accounts.services.email_service import (
    send_verification_email
)


class ForgotPasswordView(APIView):

    @swagger_auto_schema(
        request_body=ForgotPasswordSerializer
    )
    def post(self, request):

        serializer = ForgotPasswordSerializer(
            data=request.data
        )

        serializer.is_valid(
            raise_exception=True
        )

        email = serializer.validated_data["email"]

        user = User.objects(
            email=email
        ).first()

        if not user:
            return Response(
                {
                    "message": "User not found","status":"404_NOT_FOUND"
                },
                status=status.HTTP_404_NOT_FOUND
            )

        reset_token = generate_verification_token()

        PasswordResetToken(
            user=user,
            token=reset_token
        ).save()

        send_verification_email(
            email=user.email,
            otp=reset_token
        )

        return Response(
            {
                "message": "Password reset link sent successfully","status":"200_OK"
            },
            status=status.HTTP_200_OK
        )