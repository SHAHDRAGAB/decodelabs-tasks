from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.models.session import Session


class LogoutSessionView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request, session_id):

        session = Session.objects(
            id=session_id,
            user=request.user
        ).first()

        if not session:
            return Response(
                {"message": "Session not found", "status": "404_NOT_FOUND"},
                status=404
            )

        session.is_active = False
        session.save()

        return Response({"message": "Session terminated"})
