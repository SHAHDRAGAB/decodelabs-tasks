from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from accounts.serializers.register_serializer import RegisterSerializers
from drf_yasg.utils import (
    swagger_auto_schema
)

class RegisterView(APIView):
    @swagger_auto_schema(

    request_body=
    RegisterSerializers
)

    def post(self, request):

        serializer = RegisterSerializers(
            data=request.data
        )

        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(
            {
                "message": "User Registered Successfully ","status":"201 created"
            },
            status=status.HTTP_201_CREATED
        )