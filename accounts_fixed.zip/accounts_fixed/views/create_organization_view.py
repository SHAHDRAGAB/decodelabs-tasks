from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.models.organization import Organization


class CreateOrganizationView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):

        name = request.data.get("name")
        slug = request.data.get("slug")

        if Organization.objects(slug=slug).first():
            return Response(
                {"message": "Slug already exists", "status": "400_BAD_REQUEST"},
                status=400
            )

        organization = Organization(name=name, slug=slug)
        organization.save()

        user = request.user
        user.organization = organization
        user.save()

        return Response({
            "message": "Organization created",
            "status": "201_CREATED",
            "organization_id": str(organization.id)
        })
