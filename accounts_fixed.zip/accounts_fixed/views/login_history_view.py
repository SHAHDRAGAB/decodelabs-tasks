from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.models.login_history import LoginHistory


class LoginHistoryView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):

        history = LoginHistory.objects(
            user=request.user
        ).order_by("-login_time")

        data = []

        for item in history:
            data.append({
                "ip_address": item.ip_address,
                "user_agent": item.user_agent,
                "login_time": item.login_time
            })

        return Response(data)
