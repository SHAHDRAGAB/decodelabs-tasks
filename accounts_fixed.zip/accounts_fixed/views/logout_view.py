from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.models.blacklist_token import BlackListedToken


class LogoutView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response(
                {"message": "Refresh token required", "status": "400_BAD_REQUEST"},
                status=status.HTTP_400_BAD_REQUEST
            )
        BlackListedToken(token=refresh_token).save()
        return Response(
            {"message": "Logged out successfully", "status": "200_OK"},
            status=status.HTTP_200_OK
        )
