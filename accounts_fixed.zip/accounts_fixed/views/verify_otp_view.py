from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from accounts.models.user import User
from accounts.models.otp import OTP
from accounts.services.jwt_services import (
    generate_access_token,
    generate_refresh_token
)
from accounts.models.session import Session


class VerifyOTPView(APIView):

    def post(self, request):

        email = request.data.get("email", "").strip().lower()
        code = request.data.get("otp_code", "").strip()

        if not email or not code:
            return Response({
                "message": "Email and OTP are required","status":"400_BAD_REQUEST"
            }, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects(email=email).first()

        if not user:
            return Response({
                "message": "User not found","status":"404_NOT_FOUND"
            }, status=status.HTTP_404_NOT_FOUND)

        otp = OTP.objects(
            user=user,
            code=code,
        ).first()

        if not otp:
            return Response({
                "message": "Invalid OTP","status":"400_BAD_REQUEST"
            }, status=status.HTTP_400_BAD_REQUEST)

        # expiry check (لو موجودة)
        if hasattr(otp, "is_expired") and otp.is_expired:
            return Response({
                "message": "OTP expired","status":"400_BAD_REQUEST"
            }, status=status.HTTP_400_BAD_REQUEST)

        user.is_verified = True
        user.save()

        otp.delete()

        access_token = generate_access_token(user)
        refresh_token = generate_refresh_token(user)

        Session(
            user=user,
            refresh_token=refresh_token,
            ip_address=request.META.get("REMOTE_ADDR"),
            user_agent=request.META.get("HTTP_USER_AGENT")
        ).save()

        return Response({
            "message": "Email verified successfully",
            "access": access_token,
            "refresh": refresh_token,
            "status":"200_OK"
        }, status=status.HTTP_200_OK)