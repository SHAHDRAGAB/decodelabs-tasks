from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication


class EnableMFAView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):

        user = request.user
        user.mfa_enabled = True
        user.save()

        return Response({"message": "MFA enabled", "status": "200_OK"})
