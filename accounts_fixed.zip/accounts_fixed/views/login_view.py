from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from accounts.serializers.login_serializers import LoginSerializers
from accounts.services.jwt_services import generate_access_token, generate_refresh_token
from accounts.models.login_history import LoginHistory
from django_ratelimit.decorators import ratelimit
from django.utils.decorators import method_decorator
from accounts.models.otp import OTP
from accounts.services.otp_service import generate_otp
from accounts.models.session import Session
from accounts.services.email_service import send_verification_email
from drf_yasg.utils import (
    swagger_auto_schema
)
@method_decorator(
    ratelimit(
        key='ip',
        rate='5/m',
        method='POST',
        block=True
    ),
    name='post'
)


class LoginView(APIView):
    @swagger_auto_schema(

    request_body=
    LoginSerializers
)

    def post(self, request):
        serializer = LoginSerializers(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = serializer.validated_data['user']

        # معلومات الجهاز والـ IP
        ip_address = request.META.get("REMOTE_ADDR")
        user_agent = request.META.get("HTTP_USER_AGENT")

        # لو الـ MFA شغال
        if user.mfa_enabled:
            otp_code = generate_otp()

            OTP(user=user, code=otp_code).save()

            # تسجيل محاولة الدخول
            LoginHistory(
                user=user,
                ip_address=ip_address,
                user_agent=user_agent
            ).save()

            send_verification_email(
                user=user,
                otp=otp_code
            )

            return Response(
                {
                    "message": "OTP sent",
                    "user_id": str(user.id),
                    "status":"200_OK"
                },
                status=status.HTTP_200_OK
            )

        # Generate Tokens
        access_token = generate_access_token(user)
        refresh_token = generate_refresh_token(user)
        Session(user=user,refresh_token=refresh_token,ip_address=request.META.get("REMOTE_ADDR"),user_agent=request.META.get("HTTP_USER_AGENT")).save()

        # تسجيل الدخول
        LoginHistory(
            user=user,
            ip_address=ip_address,
            user_agent=user_agent
        ).save()

        return Response(
            {
                "access": access_token,
                "refresh": refresh_token
            },
            status=status.HTTP_200_OK
        )