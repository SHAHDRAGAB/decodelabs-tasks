from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from accounts.models.password_reset import (
    PasswordResetToken
)


class ResetPasswordView(APIView):

    def post(self, request, token):

        password_reset = (
            PasswordResetToken.objects(
                token=token,
                is_used=False
            ).first()
        )

        if not password_reset:
            return Response(
                {
                    "message": "Invalid token","status":"400_BAD_REQUEST"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        new_password = request.data.get(
            "password"
        )

        confirm_password = request.data.get(
            "confirm_password"
        )

        if new_password != confirm_password:
            return Response(
                {
                    "message": "Passwords do not match","status":"400_BAD_REQUEST"
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        user = password_reset.user

        user.set_password(new_password)

        user.save()

        password_reset.is_used = True

        password_reset.save()

        return Response(
            {
                "message": "Password reset successful","status":"200_OK"
            },
            status=status.HTTP_200_OK
        )