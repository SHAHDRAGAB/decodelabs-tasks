from rest_framework.views import APIView
from rest_framework.response import Response
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.permissions.can_view_dashboard import ManageUsersPermission



class AdminDashboard(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [ManageUsersPermission]


    def get(self, request):

        return Response({
            "message": "Admin Dashboard"
        })
