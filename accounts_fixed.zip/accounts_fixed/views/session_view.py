from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from accounts.authentication.jwt_authentication import JWTAuthentication
from accounts.models.session import Session


class SessionsView(APIView):

    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):

        sessions = Session.objects(
            user=request.user,
            is_active=True
        )

        data = []

        for session in sessions:
            data.append({
                "id": str(session.id),
                "ip_address": session.ip_address,
                "user_agent": session.user_agent,
                "created_at": session.created_at
            })

        return Response(data)
