import random

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from datetime import timedelta
from django.utils import timezone
from accounts.models.user import User
from accounts.models.email_otp import EmailOTP

from accounts.services.email_service import (
    send_verification_email
)

class ResendOTPView(APIView):

    def post(self, request):

        email = request.data.get("email")

        if not email:

            return Response({
                "message": "Email is required", "status":"400_BAD_REQUEST"
            }, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects(
            email=email
        ).first()

        if not user:

            return Response({
                "message": "User not found" , "status":"404_NOT_FOUND"
            }, status=status.HTTP_404_NOT_FOUND)

        if user.is_verified:

            return Response({
                "message": "Email already verified" , "status":"400_BAD_REQUEST"
            }, status=status.HTTP_400_BAD_REQUEST)

        # حذف أي OTP قديم
        EmailOTP.objects(
            user=user
        ).delete()

        # إنشاء OTP جديد
        otp_code = str(
            random.randint(100000, 999999)
        )
        expires_at = timezone.now() + timedelta(minutes=5)
        EmailOTP.objects.create(
            user=user,
            otp_code=otp_code,
            expires_at=expires_at
        )

        # إرسال الإيميل
        send_verification_email(
           user=user,
           otp=otp_code
)

        return Response({
            "message": "OTP sent successfully" , "status":"200_OK"
        }, status=status.HTTP_200_OK)