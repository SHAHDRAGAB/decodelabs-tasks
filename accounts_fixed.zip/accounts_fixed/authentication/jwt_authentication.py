from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed

from accounts.services.jwt_services import (
    decode_token,
    is_blacklisted
)

from accounts.models.user import User



class JWTAuthentication(BaseAuthentication):

    def authenticate(self, request):

        auth_header = request.headers.get("Authorization")


        if not auth_header:
            return None


        try:

            token = auth_header.split(" ")[1]


        except:

            raise AuthenticationFailed(
                "Invalid Authorization header"
            )


        if is_blacklisted(token):

            raise AuthenticationFailed(
                "Token is blacklisted"
            )


        payload = decode_token(token)


        if not payload:

            raise AuthenticationFailed(
                "Invalid or expired token"
            )


        user_id = payload.get("user_id")


        user = User.objects(
            id=user_id
        ).first()


        if not user:

            raise AuthenticationFailed(
                "User not found"
            )


        return (
            user,
            token
        )