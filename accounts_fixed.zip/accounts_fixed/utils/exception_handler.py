from rest_framework.views import exception_handler

def custom_exception_handler(exc, context):

    response = exception_handler(exc, context)

    if response is not None:

        message = ""

        # flatten any DRF structure
        if isinstance(response.data, dict):

            def extract_message(data):
                if isinstance(data, dict):
                    first_key = list(data.keys())[0]
                    return extract_message(data[first_key])

                if isinstance(data, list):
                    return data[0]

                return data

            message = extract_message(response.data)

        else:
            message = str(response.data)

        response.data = {
            
            "message": message
            
        }

    return response