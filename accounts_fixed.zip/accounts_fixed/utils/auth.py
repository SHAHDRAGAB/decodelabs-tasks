import jwt 
from django.conf import settings
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from accounts.models.user import User

class JwtAuthentication(BaseAuthentication):

    def authenticate(self, request):
        auth_header = request.headers.get("Authorization")

        if not auth_header:
            return None

        try:
            parts = auth_header.split()

            if len(parts) != 2:
                raise AuthenticationFailed("Invalid Authorization header")

            prefix, token = parts

            if prefix != "Bearer":
                raise AuthenticationFailed("Invalid token prefix")

            payload = jwt.decode(
                token,
                settings.SECRET_KEY,
                algorithms=["HS256"]
            )
           

            user_id = payload.get("user_id")

            if not user_id:
                raise AuthenticationFailed("Token has no user_id")

            if payload.get("type") != "access":
                raise AuthenticationFailed("Invalid token type")

            user = User.objects(id=str(user_id)).first()

            if not user:
                raise AuthenticationFailed("User not found")

            return (user, None)

        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed("Token expired")

        except jwt.InvalidTokenError:
            raise AuthenticationFailed("Invalid token")