from django.apps import AppConfig
from accounts.seed import run_seeds

class AccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accounts'
    def ready(self):
       
        run_seeds()
