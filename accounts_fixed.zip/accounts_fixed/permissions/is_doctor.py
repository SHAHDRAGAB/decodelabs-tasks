from rest_framework.permissions import (
    BasePermission
)


class IsDoctor(BasePermission):

    def has_permission(self, request, view):
        user = request.user

        return (
            user.is_authenticated
            and user.role
            and user.role.name.lower() == "doctor"
        )