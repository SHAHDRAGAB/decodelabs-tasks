from rest_framework.views import APIView
from rest_framework.response import Response

# from accounts.permissions.has_permission import HasPermission


from .base import HasPermission



class ManageUsersPermission(HasPermission):

    permission_required = "manage_users"



class ClinicalChatPermission(HasPermission):

    permission_required = "clinical_chat"