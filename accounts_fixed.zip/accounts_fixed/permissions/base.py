from rest_framework.permissions import BasePermission



class HasPermission(BasePermission):

    permission_required = None


    def has_permission(self, request, view):

        user = request.user


        if not user.is_authenticated:
            return False


        if not user.role:
            return False


        permissions = [
            p.name
            for p in user.role.permissions
        ]


        return self.permission_required in permissions