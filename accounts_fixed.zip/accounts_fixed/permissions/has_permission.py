# from rest_framework.permissions import BasePermission

# class HasPermission(BasePermission):

#     required_permission = None

#     def has_permission(self, request, view):

#         user = request.user

#         if not user or not user.role:
#             return False

#         role_permissions = user.role.permissions

#         permission_names = [
#             p.name for p in role_permissions
#         ]

#         return self.required_permission in permission_names