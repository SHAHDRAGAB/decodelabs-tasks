from rest_framework.test import (
    APITestCase
)

from accounts.models import User


class LoginTest(APITestCase):

    def setUp(self):

        User(
            username="shahd",
            email="test@test.com"
        ).set_password(
            "123456"
        ).save()

    def test_login(self):

        response = self.client.post(

            "/api/accounts/login/",

            {

                "email":
                "test@test.com",

                "password":
                "123456"
            }
        )

        self.assertEqual(
            response.status_code,
            200
        )