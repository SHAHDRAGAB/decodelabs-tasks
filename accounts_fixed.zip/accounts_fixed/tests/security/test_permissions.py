from rest_framework.test import (
    APITestCase
)


class PermissionTest(
    APITestCase
):

    def test_protected_route(self):

        response = self.client.get(
            "/api/orders/"
        )

        self.assertEqual(
            response.status_code,
            401
        )