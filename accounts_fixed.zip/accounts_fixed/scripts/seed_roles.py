from accounts.models.role import Role



roles = [
    "admin",
    "healthcare_provider",
    "healthcare_institution",
    "deaf_user"
]


for role_name in roles:

    role = Role.objects(
        name=role_name
    ).first()


    if not role:

        Role(
            name=role_name
        ).save()


print("Roles done")