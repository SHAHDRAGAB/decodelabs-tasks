# This file is kept for backward compatibility.
# The actual implementation is in accounts/authentication/jwt_authentication.py
from accounts.authentication.jwt_authentication import JWTAuthentication

__all__ = ["JWTAuthentication"]
