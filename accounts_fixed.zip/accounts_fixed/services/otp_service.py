import random

from datetime import (
    datetime,
    timedelta
)

from accounts.models.email_otp import (
    EmailOTP
)


def generate_otp():

    return str(
        random.randint(
            100000,
            999999
        )
    )


def create_email_otp(user):

    otp = generate_otp()

    EmailOTP.objects(
        user=user
    ).delete()

    EmailOTP(

        user=user,
        otp_code=otp,
        expires_at=
        datetime.utcnow()
        +
        timedelta(minutes=6)

    ).save()

    return otp