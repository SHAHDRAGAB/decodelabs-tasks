from django.core.mail import (
    send_mail
)

from django.conf import settings


def send_verification_email(
    user,
    otp
):

    send_mail(

        subject="Verify Your Account",

        message=(
            f"Your verification "
            f"code is: {otp}"
        ),

        from_email=
        settings.EMAIL_HOST_USER,

        recipient_list=[user.email],

        fail_silently=False
    )