import jwt
from datetime import timedelta,datetime
from django.conf import settings
from accounts.models.blacklist_token import BlackListedToken

SECRET_KEY=settings.SECRET_KEY

def generate_access_token(user):
    payload={
        "user_id":str(user.id),
        "email":user.email,
        "exp": datetime.utcnow() + timedelta(hours=12),
        "type":"access"
    }
    return jwt.encode(payload,SECRET_KEY,algorithm="HS256")


def generate_refresh_token(user):
    payload={
        "user_id":str(user.id),
        "exp": datetime.utcnow() + timedelta(days=7),
        "type":"refresh"
    }
    return jwt.encode(payload,SECRET_KEY,algorithm="HS256")

def is_blacklisted(token):
    return BlackListedToken.objects(token=token).first() is not None
def decode_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload

    except jwt.ExpiredSignatureError:
        return None

    except jwt.InvalidTokenError:
        return None


# def is_blacklisted(token):
#     return BlackListedToken.objects(token=token).first() is not None